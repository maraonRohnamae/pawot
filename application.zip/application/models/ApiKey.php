<?php
use Illuminate\Database\Eloquent\Model;

class ApiKey extends Model
{
    protected $table = 'sys_api';
    public $timestamps = false;

}