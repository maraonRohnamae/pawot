Plugins directory- /application/plugins/ has been moved to /apps/ directory
If you have old plugins reside here, please move plugin folders to /apps/ directory.