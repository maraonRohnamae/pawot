<?php
$host = 'sql12.freesqldatabase.com';
$db_name = 'sql12745722';
$username = 'sql12745722'; // Use 'root' for default XAMPP MySQL user
$password = 'fhJZkkz87S'; // Leave empty for the default password in XAMPP


$db = new mysqli($host, $username, $password, $db_name);

// Check connection
if ($db->connect_error) {
die("Connection failed: " . $db->connect_error);
}
?>