<?php
add_menu_admin('Notes',U.'notes/init/list/','notes','fa fa-file-o');

Event::bind('invoices/add/',function(){
   // Your Code Here
});