<?php
class Models_Invoice extends Model
{
    public static $_table = 'sys_invoices';
}
