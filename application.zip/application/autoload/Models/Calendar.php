<?php
class Models_Calendar extends Model
{
    public static $_table = 'sys_events';
}
